/**
 */
package jointPackage_BibTeX2DocBook;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Src In Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see jointPackage_BibTeX2DocBook.JointPackage_BibTeX2DocBookPackage#getSrcInCollection()
 * @model
 * @generated
 */
public interface SrcInCollection extends SrcBook, SrcBookTitledEntry {
} // SrcInCollection

/**
 */
package jointPackage_BibTeX2DocBook;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Src In Proceedings</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see jointPackage_BibTeX2DocBook.JointPackage_BibTeX2DocBookPackage#getSrcInProceedings()
 * @model
 * @generated
 */
public interface SrcInProceedings extends SrcProceedings, SrcAuthoredEntry, SrcBookTitledEntry {
} // SrcInProceedings

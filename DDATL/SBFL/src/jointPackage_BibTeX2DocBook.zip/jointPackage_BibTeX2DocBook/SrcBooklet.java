/**
 */
package jointPackage_BibTeX2DocBook;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Src Booklet</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see jointPackage_BibTeX2DocBook.JointPackage_BibTeX2DocBookPackage#getSrcBooklet()
 * @model
 * @generated
 */
public interface SrcBooklet extends SrcDatedEntry {
} // SrcBooklet

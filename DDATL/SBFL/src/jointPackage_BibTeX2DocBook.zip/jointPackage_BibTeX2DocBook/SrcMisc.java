/**
 */
package jointPackage_BibTeX2DocBook;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Src Misc</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see jointPackage_BibTeX2DocBook.JointPackage_BibTeX2DocBookPackage#getSrcMisc()
 * @model
 * @generated
 */
public interface SrcMisc extends SrcBibTeXEntry {
} // SrcMisc

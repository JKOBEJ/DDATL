/**
 */
package jointPackage_BibTeX2DocBook;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Src Master Thesis</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see jointPackage_BibTeX2DocBook.JointPackage_BibTeX2DocBookPackage#getSrcMasterThesis()
 * @model
 * @generated
 */
public interface SrcMasterThesis extends SrcThesisEntry {
} // SrcMasterThesis

/**
 */
package jointPackage_BibTeX2DocBook;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Src Proceedings</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see jointPackage_BibTeX2DocBook.JointPackage_BibTeX2DocBookPackage#getSrcProceedings()
 * @model
 * @generated
 */
public interface SrcProceedings extends SrcDatedEntry, SrcTitledEntry {
} // SrcProceedings
